# 跨窗口恢复验收

仅用于本轮恢复流程验收。

## 取消恢复验收 · 旅人

<a id="card-d0000000-0000-4000-8000-000000000000"></a>

类型：角色

别名：备份检查

标签：整包备份验收

关闭窗口后恢复，前往 [续传验收 · 港口](#card-d0000000-0000-4000-8000-000000000001)。

- 序号：1

- 同行 → [续传验收 · 港口](#card-d0000000-0000-4000-8000-000000000001)

![取消恢复验收 · 旅人 · 封面](<./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png>)

![取消恢复验收 · 旅人 · 图片 1](<./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png>)

## 续传验收 · 港口

<a id="card-d0000000-0000-4000-8000-000000000001"></a>

类型：地点

别名：备份检查

标签：整包备份验收

关闭窗口后恢复，前往 [取消恢复验收 · 旅人](#card-d0000000-0000-4000-8000-000000000000)。

- 序号：2

- 同行 → [取消恢复验收 · 旅人](#card-d0000000-0000-4000-8000-000000000000)

![续传验收 · 港口 · 图片 1](<./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png>)
<!-- taichu-world:v1
{"version":1,"textChecksum":"da454a6","cards":[{"sourceId":"d0000000-0000-4000-8000-000000000000","payload":{"title":"取消恢复验收 · 旅人","type":"character","subType":null,"description":"关闭窗口后恢复，前往 {CARD:d0000000-0000-4000-8000-000000000001}。","content":"{}","coverImage":"[\"./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png\"]","galleryImages":["./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png"],"aliases":["备份检查"],"tags":["整包备份验收"],"attributes":[{"key":"序号","value":"1","type":"number"}],"contentBlocks":[],"embeddedCards":[],"timelineEvents":[],"relations":[{"targetCardId":"d0000000-0000-4000-8000-000000000001","relationType":"同行"}]}},{"sourceId":"d0000000-0000-4000-8000-000000000001","payload":{"title":"续传验收 · 港口","type":"location","subType":null,"description":"关闭窗口后恢复，前往 {CARD:d0000000-0000-4000-8000-000000000000}。","content":"{}","coverImage":null,"galleryImages":["./images/b2deb5949ed2c24424db4b81ec063980463bf23711c14b1471840935de8ee5e3.png"],"aliases":["备份检查"],"tags":["整包备份验收"],"attributes":[{"key":"序号","value":"2","type":"number"}],"contentBlocks":[],"embeddedCards":[],"timelineEvents":[],"relations":[{"targetCardId":"d0000000-0000-4000-8000-000000000000","relationType":"同行"}]}}]}
-->
